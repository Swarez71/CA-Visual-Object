
#include "extend.h"

/*
	Parm 1 is key string
	Parm 2 is hash table size

*/

CLIPPER CsyHashVal(void)
{
	char *p;
	unsigned hashVal = 0;

	for (p = _parc(1); *p; hashVal = (hashVal << 1) ^ *p++)
		;

	_retni(hashVal % _parni(2) + 1);
}
